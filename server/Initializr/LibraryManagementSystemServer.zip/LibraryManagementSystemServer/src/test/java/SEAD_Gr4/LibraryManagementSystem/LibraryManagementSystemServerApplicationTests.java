package SEAD_Gr4.LibraryManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryManagementSystemServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
